<?php 
/**
 * @package EvolutionScript
 * @author: EvolutionScript S.A.C.
 * @Copyright (c) 2010 - 2020, EvolutionScript.com
 * @link http://www.evolutionscript.com
 */


use App\Controllers\BaseController;
use App\Models\SystemParamsModel;
use Config\Services;


class SystemParams extends BaseController
{

    public function editParam($id){
        if($this->request->getPost('do') == 'submit'){

        }
    }


}

 ?>